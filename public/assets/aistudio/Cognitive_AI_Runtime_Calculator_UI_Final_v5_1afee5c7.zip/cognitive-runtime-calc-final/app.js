const screens = [
  {id:'screenUnderstand', kicker:'STEP 1 · UNDERSTAND', title:'What did the Runtime understand from me?', status:'NEEDS 1 DECISION'},
  {id:'screenPlan', kicker:'STEP 2 · PLAN', title:'What will the Runtime do — and why?', status:'PLAN READY'},
  {id:'screenWork', kicker:'STEP 3 · WORK', title:'What is happening right now?', status:'VERIFYING'},
  {id:'screenCheck', kicker:'STEP 4 · CHECK', title:'Did the result actually satisfy the task?', status:'1 REQUIRED FAILURE'},
  {id:'screenResult', kicker:'STEP 5 · RESULT', title:'Can I trust the result — and what proves it?', status:'VERIFIED COMPLETE'}
];
let current = 0;
let clarified = false;
let repaired = false;
const $ = id => document.getElementById(id);
const steps = [...document.querySelectorAll('.step')];

function render(){
  screens.forEach((s,i)=>$(s.id).classList.toggle('hidden', i!==current));
  steps.forEach((b,i)=>{b.classList.toggle('active',i===current);b.classList.toggle('done',i<current)});
  [...document.querySelectorAll('.step-line')].forEach((l,i)=>l.classList.toggle('done',i<current));
  const s=screens[current];
  $('screenKicker').textContent=s.kicker;
  $('screenTitle').textContent=s.title;
  $('screenStatus').textContent=current===3 && repaired ? 'RE-VERIFIED' : s.status;
  $('stageCounter').textContent=`${current+1} / 5`;
  $('prevBtn').disabled=current===0;
  $('nextBtn').disabled=current===4 || (current===0 && !clarified) || (current===3 && !repaired);
  const global=$('globalStatus'); global.className='status';
  let txt='READY';
  if(current===0) txt=clarified?'UNDERSTOOD':'WAITING FOR INPUT';
  if(current===1) txt='PLANNED';
  if(current===2) txt='VERIFYING';
  if(current===3 && !repaired){txt='CHECK FAILED'; global.classList.add('warn');}
  if(current===3 && repaired){txt='RE-VERIFIED'; global.classList.add('ok');}
  if(current===4){txt='VERIFIED COMPLETE'; global.classList.add('ok');}
  global.querySelector('b').textContent=txt;
}
function go(i){current=Math.max(0,Math.min(4,i));render();window.scrollTo({top:document.getElementById('runtimeShell').offsetTop-84,behavior:'smooth'});}
steps.forEach((b,i)=>b.addEventListener('click',()=>{if(i===0||clarified)go(i)}));
$('prevBtn').onclick=()=>go(current-1);
$('nextBtn').onclick=()=>go(current+1);

// Clarification is deliberately material: platform changes the product.
document.querySelectorAll('.choice-btn').forEach(btn=>btn.addEventListener('click',()=>{
  document.querySelectorAll('.choice-btn').forEach(b=>b.classList.remove('selected'));
  btn.classList.add('selected');
  if(btn.dataset.choice==='desktop'){
    $('desktopNote').classList.remove('hidden');
    $('clarificationAnswer').classList.add('hidden');
    clarified=false;
  }else{
    $('desktopNote').classList.add('hidden');
    $('clarificationAnswer').classList.remove('hidden');
    clarified=true;
    setTimeout(render,50);
  }
  render();
}));

// Generic disclosure buttons.
document.querySelectorAll('[data-target]').forEach(btn=>{
  if(btn.classList.contains('step')||btn.classList.contains('choice-btn')) return;
  btn.addEventListener('click',()=>{
    const target=$(btn.dataset.target);
    target.classList.toggle('hidden');
    if(btn.classList.contains('details-toggle')) btn.classList.toggle('open',!target.classList.contains('hidden'));
  });
});

$('repairBtn').onclick=()=>{
  repaired=true;
  $('repairOffer').classList.add('hidden');
  $('repairHistory').classList.remove('hidden');
  $('acceptanceScore').textContent='8 / 8 ✓';
  $('acceptanceNote').textContent='All required behaviors now pass.';
  $('acceptanceCard').classList.remove('fail'); $('acceptanceCard').classList.add('ok');
  $('failureStory').classList.add('hidden');
  $('traceZero').innerHTML='<span>Safe invalid division</span><span>Division handler + zero guard</span><span>DIV-ZERO-01 + regression</span><b class="pass">PASS</b>';
  render();
};

$('openResultBtn').onclick=()=>{$('resultPreview').classList.toggle('hidden');};

$('resetBtn').onclick=()=>{
  current=0; clarified=false; repaired=false;
  document.querySelectorAll('.choice-btn').forEach(b=>b.classList.remove('selected'));
  $('desktopNote').classList.add('hidden'); $('clarificationAnswer').classList.add('hidden');
  $('repairOffer').classList.remove('hidden'); $('repairHistory').classList.add('hidden'); $('failureStory').classList.remove('hidden');
  $('acceptanceScore').textContent='7 / 8 ✕'; $('acceptanceNote').textContent='One required behavior failed.';
  $('acceptanceCard').className='summary-card fail';
  $('traceZero').innerHTML='<span>Safe invalid division</span><span>Division handler</span><span>DIV-ZERO-01</span><b class="fail">FAIL</b>';
  $('resultPreview').classList.add('hidden');
  document.querySelectorAll('.details-panel,.why-panel').forEach(x=>x.classList.add('hidden'));
  document.querySelectorAll('.details-toggle').forEach(x=>x.classList.remove('open'));
  render();
};

// Calculator preview — deterministic; no eval()/Function().
let display='0',stored=null,op=null;
function press(k){
  if(/^[0-9.]$/.test(k)) display=(display==='0'||display==='Error')?k:display+k;
  else if(['+','-','×','÷'].includes(k)){stored=Number(display);op=k;display='0';}
  else if(k==='C'){display='0';stored=null;op=null;}
  else if(k==='='&&stored!==null&&op){const v=Number(display);if(op==='÷'&&v===0)display='Error';else if(op==='+')display=String(stored+v);else if(op==='-')display=String(stored-v);else if(op==='×')display=String(stored*v);else display=String(stored/v);stored=null;op=null;}
  $('calcDisplay').textContent=display;
}
['7','8','9','÷','4','5','6','×','1','2','3','-','0','.','C','+','='].forEach(k=>{const b=document.createElement('button');b.textContent=k;if(['+','-','×','÷'].includes(k))b.className='op';if(k==='=')b.className='eq';b.onclick=()=>press(k);$('calcGrid').appendChild(b)});

render();
