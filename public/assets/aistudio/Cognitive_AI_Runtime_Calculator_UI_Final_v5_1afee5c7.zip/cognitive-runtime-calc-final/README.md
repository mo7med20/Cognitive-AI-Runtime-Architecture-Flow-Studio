# Cognitive AI Runtime — Calculator Reference UI (Final UX)

A user-first interactive sample of the Cognitive AI Runtime lifecycle.

## Run

```bash
python -m http.server 8080 --directory .
```

Open http://localhost:8080

## Demo path
1. Understand: choose **Web**.
2. Plan: inspect **Why?** only when needed.
3. Work: show `Agent = implementation complete` while `Task = verifying`.
4. Check: show 7/8 acceptance checks, 13/13 evidence, then click **Fix & verify again**.
5. Result: show verified completion, proof, history, and the working calculator.

## Important product logic represented
- Preferred language is a preference, not a mandatory rule.
- Runtime chooses Vanilla TypeScript + Vite because the task is small and does not justify React/Next.js.
- Runtime-added quality requirement is visibly separated from user requirements.
- Evidence coverage and acceptance pass rate are separate concepts.
- Repair history remains visible after the repair.
- Primary UX uses user language; technical architecture stays under progressive disclosure.
